package Question3;
abstract class Shape 
{
	abstract double area();
}
