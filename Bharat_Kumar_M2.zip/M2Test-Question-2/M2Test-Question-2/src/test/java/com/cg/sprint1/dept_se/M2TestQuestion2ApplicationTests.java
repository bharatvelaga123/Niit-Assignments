package com.cg.sprint1.dept_se;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M2TestQuestion2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
