package com.cg.sprint1.dept_se.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sprint1.dept_se.entity.Department;
import com.cg.sprint1.dept_se.repository.DepartmentRepository;

@Service
public class DepartmentService 
{

	@Autowired
	static
	DepartmentRepository departmentRepository;
	public static Department getDetailsById(String dept_no) 
	{
		Optional<Department> mvopt = departmentRepository.findById(dept_no);
		if(mvopt!=null)
			return mvopt.get();
		throw new RuntimeException("No booking is done by that id");
	}
	public boolean addDepartmentDetails(Department department) 
	{
		Department sbi = departmentRepository.save(department);
		return (sbi!=null);
	}
	public static boolean modifyDetails(Department department) 
	{
		if(departmentRepository.existsById(department.getBookingId()))
			departmentRepository.save(department);
		throw new RuntimeException("No booking is done by this id");
	}
	public static void removeByID(String dept_no) 
	{
		departmentRepository.deleteById(dept_no);
		
	}
	
	
}
