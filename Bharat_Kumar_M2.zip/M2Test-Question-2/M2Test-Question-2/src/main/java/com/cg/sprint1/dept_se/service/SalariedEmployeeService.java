package com.cg.sprint1.dept_se.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sprint1.dept_se.entity.SalariedEmployee;
import com.cg.sprint1.dept_se.repository.SalariedEmployeeRepository;

@Service
public class SalariedEmployeeService 
{
	@Autowired
	static
	SalariedEmployeeRepository salariedEmployeeRepository;

	public SalariedEmployee getDetailsById(String emp_Id) 
	{
		Optional<SalariedEmployee> mvopt = salariedEmployeeRepository.findById(emp_Id);
		if(mvopt!=null)
			return mvopt.get();
		throw new RuntimeException("No booking is done by that id");
	}

	public boolean addemployeeDetails(SalariedEmployee salariedEmployee) 
	{
		SalariedEmployee sbi = salariedEmployeeRepository.save(salariedEmployee);
		return (sbi!=null);
	}

	public static boolean modifyDetails(SalariedEmployee salariedEmployee)
	{
		if(salariedEmployeeRepository.existsById(salariedEmployee.getBookingId()))
			salariedEmployeeRepository.save(salariedEmployee);
		throw new RuntimeException("No booking is done by this id");
	}

	public static void removeByID(String emp_Id) 
	{
		salariedEmployeeRepository.deleteById(emp_Id);
		
	}
	
	
}
