package com.cg.sprint1.dept_se.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sprint1.dept_se.entity.Department;
import com.cg.sprint1.dept_se.entity.SalariedEmployee;
import com.cg.sprint1.dept_se.service.SalariedEmployeeService;

@RestController
@RequestMapping("/salariedEmployee")
public class SalariedEmployeeController 
{
	@Autowired
	SalariedEmployeeService salariedEmployeeService;
	
	@GetMapping(value="/{emp_Id}",produces="application/json")
	public ResponseEntity<SalariedEmployee> getDetails(@PathVariable String emp_Id )
	{
		SalariedEmployee sb = salariedEmployeeService.getDetailsById(emp_Id);
		return  new ResponseEntity<SalariedEmployee>(sb,HttpStatus.OK);
	} 
	
	@PostMapping(value="/emp_Id",consumes="application/json")
	public HttpStatus addDetails(@RequestBody SalariedEmployee salariedEmployee)
	{
		if(salariedEmployeeService.addemployeeDetails(salariedEmployee))
			return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;
	}
	
	@PutMapping(consumes="application/json")
	public HttpStatus modifyDetails(@RequestBody SalariedEmployee salariedEmployee)
	{
		if(SalariedEmployeeService.modifyDetails(salariedEmployee))
			return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;	
	}
	
	@DeleteMapping(value="/delete/{emp_Id}")
	public HttpStatus delete(@PathVariable String emp_Id)
	{
		SalariedEmployeeService.removeByID(emp_Id);
		return HttpStatus.OK;
	}
}
