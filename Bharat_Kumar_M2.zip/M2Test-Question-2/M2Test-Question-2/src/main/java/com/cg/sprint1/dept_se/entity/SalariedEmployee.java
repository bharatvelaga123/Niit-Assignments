package com.cg.sprint1.dept_se.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="salariedEmployee")
public class SalariedEmployee 
{
	@Id
	@Column(name="emp_Id")
	private String employeeId;
	
	@Column(name="emp_Name")
	private String employeeName;
	
	@Column(name="emp_Sal")
	private String employeeSalary;
	
	@ManyToOne
	@JoinColumn(name="dept_no")
	Department department;
	
	public SalariedEmployee() {}

	public SalariedEmployee(String employeeId, String employeeName, String employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(String employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getBookingId() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
/*employeeId;
       employeeName;
       employeeSalary;*/