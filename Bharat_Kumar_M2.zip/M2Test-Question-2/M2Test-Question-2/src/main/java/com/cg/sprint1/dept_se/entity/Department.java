package com.cg.sprint1.dept_se.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="department")
public class Department 
{
	@Id
	@Column(name="dept_no")
	private String departmentNo;
	
	@Column(name="dept_name")
	private String departmentName;
	
	@Column(name="dept_loc")
	private String departmentLocation;
	
	@OneToMany(fetch=FetchType.EAGER,mappedBy="department")
	List<SalariedEmployee> salariedEmployee;
	
	public Department() {}

	public Department(String departmentNo, String departmentName, String departmentLocation) {
		super();
		this.departmentNo = departmentNo;
		this.departmentName = departmentName;
		this.departmentLocation = departmentLocation;
	}

	public String getDepartmentNo() {
		return departmentNo;
	}

	public void setDepartmentNo(String departmentNo) {
		this.departmentNo = departmentNo;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentLocation() {
		return departmentLocation;
	}

	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}

	public String getBookingId() {
		// TODO Auto-generated method stub
		return null;
	}	
}
/*departmentNo;
       departmentName;
       departmentLocation;*/