package com.cg.sprint1.dept_se.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.sprint1.dept_se.entity.SalariedEmployee;

@Repository
public interface SalariedEmployeeRepository extends JpaRepository<SalariedEmployee , String>
{

}
