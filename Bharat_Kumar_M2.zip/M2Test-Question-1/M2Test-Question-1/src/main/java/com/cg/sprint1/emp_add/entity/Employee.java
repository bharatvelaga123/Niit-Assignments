package com.cg.sprint1.emp_add.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Employee 
{
	@Id
	@Column(name="emp_Id")
	int employeeId;
	
	@Column(name="employee_Name")
	int employeeName;
	
	@Column(name="employee_Salary")
	int employeeSalary;
	
	@Column(name="employee_DOB")
	int employeeDOB;
	
	@OneToOne
	@JoinColumn(name="add_id")
	Address address;
	public Employee() {}

	public Employee(int employeeId, int employeeName, int employeeSalary, int employeeDOB) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.employeeDOB = employeeDOB;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(int employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public int getEmployeeDOB() {
		return employeeDOB;
	}

	public void setEmployeeDOB(int employeeDOB) {
		this.employeeDOB = employeeDOB;
	}

	public String getBookingId() 
	{
		// TODO Auto-generated method stub
		return null;
	}
}
/* employeeId;
       employeeName;
       employeeSalary;
       employeeDOB;*/