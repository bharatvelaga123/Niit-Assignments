package com.cg.sprint1.emp_add.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sprint1.emp_add.entity.Address;
import com.cg.sprint1.emp_add.repository.AddressRepository;
@Service
public class AddressService 
{

	@Autowired
	static
	AddressRepository addressRepository;
	@Transactional(readOnly=true)

	public static Address getDetailsById(String add_Id) 
	{
		Optional<Address> mvopt = addressRepository.findById(add_Id);
		if(mvopt!=null)
			return mvopt.get();
		throw new RuntimeException("No booking is done by that id");
	}
	public static void removeByID(String add_Id) 
	{
		addressRepository.deleteById(add_Id);
		
	}

	public static boolean modifyDetails(Address address) 
	{
		if(addressRepository.existsById(address.getBookingId()))
			addressRepository.save(address);
		throw new RuntimeException("No booking is done by this id");
	}

	public boolean addAddressDetails(Address address) 
	{
		Address sbi = addressRepository.save(address);
		return (sbi!=null);
	}
}
