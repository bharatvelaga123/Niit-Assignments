package com.cg.sprint1.emp_add.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sprint1.emp_add.entity.Address;
import com.cg.sprint1.emp_add.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController 
{
	@Autowired
	AddressService addressService;
	
	@GetMapping(value="/{add_Id}",produces="application/json")
	public ResponseEntity<Address> getDetails(@PathVariable String add_Id )
	{
		Address sb = AddressService.getDetailsById(add_Id);
		return  new ResponseEntity<Address>(sb,HttpStatus.OK);
	} 
	
	@PostMapping(value="/add_Id",consumes="application/json")
	public HttpStatus addDetails(@RequestBody Address address)
	{
		if(addressService.addAddressDetails(address))
			return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;
	}
	
	@PutMapping(consumes="application/json")
	public HttpStatus modifyDetails(@RequestBody Address address)
	{
		if(AddressService.modifyDetails(address))
			return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;	
	}
	
	@DeleteMapping(value="/delete/{add_Id}")
	public HttpStatus delete(@PathVariable String add_Id)
	{
		AddressService.removeByID(add_Id);
		return HttpStatus.OK;
	}
}
