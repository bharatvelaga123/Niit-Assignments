package com.cg.sprint1.emp_add.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address 
{
	@Id
	@Column(name="add_id")
	String addressId;
	
	@Column(name="add_street")
	String streetName;
	
	@Column(name="add_city")
	String city;
	
	@Column(name="add_state")
	String state;
	
	@OneToOne
	@JoinColumn(name="emp_id")
	Employee employee;
	
	public Address() {}

	public Address(String addressId, String streetName, String city, String state)
	{
		super();
		this.addressId = addressId;
		this.streetName = streetName;
		this.city = city;
		this.state = state;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getBookingId() 
	{
		// TODO Auto-generated method stub
		return null;
	}
}
/*addressId;
      	streetName;
       city;
       state;*/