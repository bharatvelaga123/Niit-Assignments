package com.cg.sprint1.emp_add.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sprint1.emp_add.entity.Address;
import com.cg.sprint1.emp_add.entity.Employee;
import com.cg.sprint1.emp_add.service.AddressService;
import com.cg.sprint1.emp_add.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController 
{
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping(value="/{emp_Id}",produces="application/json")
	public ResponseEntity<Employee> getDetails(@PathVariable String emp_Id )
	{
		Employee sb = employeeService.getDetailsById(emp_Id);
		return  new ResponseEntity<Employee>(sb,HttpStatus.OK);
	} 
	
	@PostMapping(value="/emp_id",consumes="application/json")
	public HttpStatus addDetails(@RequestBody Employee employee)
	{
		if(employeeService.addEmployeeDetails(employee))
			return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;
	}
	
	@PutMapping(consumes="application/json")
	public HttpStatus modifyDetails(@RequestBody Employee employee)
	{
		if(employeeService.modifyDetails(employee))
			return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;	
	}
	
	@DeleteMapping(value="/delete/{emp_Id}")
	public HttpStatus deleteMovie(@PathVariable String emp_Id)
	{
		employeeService.removeByID(emp_Id);
		return HttpStatus.OK;
	}
}
