package com.cg.sprint1.emp_add.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sprint1.emp_add.entity.Address;
import com.cg.sprint1.emp_add.entity.Employee;
import com.cg.sprint1.emp_add.repository.EmployeeRepository;

@Service
public class EmployeeService 
{
	@Autowired
	static
	EmployeeRepository employeeRepository;
	@Transactional(readOnly=true)
	public Employee getDetailsById(String emp_Id) 
	{
		Optional<Employee> mvopt = employeeRepository.findById(emp_Id);
		if(mvopt!=null)
			return mvopt.get();
		throw new RuntimeException("No booking is done by that id");
	}
	
	public boolean addEmployeeDetails(Employee employee) 
	{
		Employee sbi = employeeRepository.save(employee);
		return (sbi!=null);
	}

	public boolean modifyDetails(Employee employee) 
	{
		if(employeeRepository.existsById(employee.getBookingId()))
			employeeRepository.save(employee);
		throw new RuntimeException("No booking is done by this id");
	}

	public void removeByID(String emp_Id) 
	{
		employeeRepository.deleteById(emp_Id);
		
	}

	
}
