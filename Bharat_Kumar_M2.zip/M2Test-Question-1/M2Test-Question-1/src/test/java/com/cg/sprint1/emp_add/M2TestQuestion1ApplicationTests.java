package com.cg.sprint1.emp_add;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M2TestQuestion1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
